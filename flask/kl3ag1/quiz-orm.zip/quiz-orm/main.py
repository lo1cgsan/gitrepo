# -*- coding: utf-8 -*-
# quiz-orm/main.py

from app import app
from views import *

if __name__ == '__main__':
    app.run(debug=True)
